using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckAns : MonoBehaviour
{
    public static string[] Sumbol_Answer;
    public static string checkAns;
    public static int check;
    void Start()
    {
        Sumbol_Answer = new string[CreateGameLocation.check_ans];
        for (int i = 0; i < Sumbol_Answer.Length; i++)
        {
            Sumbol_Answer[i] = "?";
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public static void AddSumbol()
    {
        Sumbol_Answer[DragLetter.index] = DragLetter.sumbol;
        checkAns = "";
        for (int i = 0; i < Sumbol_Answer.Length; i++)
        {
            checkAns += Sumbol_Answer[i];
        }
        if (checkAns == CreateGameLocation.answ)
        {
            Debug.Log("���������� �����!");
            check = 1;
        }
    }
    public static void DelSumbol()
    {
        Sumbol_Answer[DragLetter.index] = "?";
        checkAns = "";
        for (int i = 0; i < Sumbol_Answer.Length; i++)
        {
            checkAns += Sumbol_Answer[i];
        }
    }
}
