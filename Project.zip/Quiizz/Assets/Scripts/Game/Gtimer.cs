using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UI;

public class Gtimer : MonoBehaviour
{

    public Text time;
    public static float second; TimeSpan timer = new TimeSpan();
    public Text text;
    bool Addtimee;
    void Start()
    {
        second = 120f;  
    }
     void Update()
    {
        
     second -= Time.deltaTime;
        timer = new TimeSpan(0,0,Convert.ToInt32(second));
    time.text = timer.ToString("mm':'ss");
        if (second <= 0)
        {
            Debug.Log("����� �����!");
            second = 0f; text.text = ("���! ����� �����!");
            
        }
        else if (CheckAns.check == 1)
        {
            second = 30;
            text.text = "�c� �����!";
        }
    }

    public void Addtime()
    {
        if (!Addtimee)
        {
            Addtimee = true;
            second += 30f;
            time.text = Convert.ToString(second) + "30";
            Addtimee = false;
            CoinsScript.CoinRemove(50);
        }
        
    }

}

