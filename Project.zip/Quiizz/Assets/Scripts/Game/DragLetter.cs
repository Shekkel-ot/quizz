using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragLetter : MonoBehaviour
{
    bool mouseDown;//���� ������ ��������������
    Vector3 offset; //��������
    public static int index;
    public static string sumbol;

    private void OnMouseDown()
    {
        mouseDown = true;
        offset = gameObject.transform.position - Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0f));
    }

    private void OnMouseUp()
    {
        mouseDown = false;
    }

    void Update()
    {
        if (mouseDown)
        {
            transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 0f));
            Vector3 newPosition = transform.position;
            transform.position = newPosition + offset;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("���� � " + collision.name);
        index = Convert.ToInt32(collision.name);
        sumbol = gameObject.name;
        CheckAns.AddSumbol();
        Debug.Log("��� �����: " + CheckAns.checkAns);
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        Debug.Log("����� �� " + collision.name);
        index = Convert.ToInt32(collision.name);
        CheckAns.DelSumbol();
        Debug.Log("��� �����: " + CheckAns.checkAns);
    }
}

