using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectTheme : MonoBehaviour
{
    public static int numTheme;
    public void BtnScienceClick()
    {
        numTheme = 1;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");
        

    }
    public void BtnHistoryclick()
    {
        numTheme = 2;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");

    }
    public void BtnArtClick()
    {
        numTheme = 3;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");

    }
    public void BtnLivingWorldClick()
    {
        numTheme = 4;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");

    }
    public void BtnCinemaClick()
    {
        numTheme = 5;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");

    }
    public void BtnSportClick()
    {
        numTheme = 6;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");

    }
    public void BtnPhraseClick()
    {
        numTheme = 7;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");

    }
    public void BtnRandomClick()
    {
        numTheme = 8;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Game");
    }
    public void ReturnToHome()
    {
        numTheme = 0;
        PlayerPrefs.SetFloat("second", EnergyScript.second);
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.SetInt("energy", EnergyScript.energy);
        PlayerPrefs.Save();
        SceneManager.LoadScene("Menu");
    }
    void SelectBtn(int num)
    {

    }
}
