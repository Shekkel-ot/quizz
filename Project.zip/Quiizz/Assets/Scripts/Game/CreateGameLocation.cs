using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class CreateGameLocation : MonoBehaviour
{
    public Transform dragLetter, emptyLetter;
    Transform dragLocation;
    public Canvas canvas;
    public Text text;
    public static int rndNumQuest;
    string alfWord;
    public static int check_ans;
    public static string answ;
    bool remove;
    // Start is called before the first frame update
    void Start()
    {
        SelectTheme.numTheme = 1;
        FillQuiz.ReadXML();
        if (SelectTheme.numTheme == 1)
        {
            rndNumQuest = Random.Range(0, 10);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question;
            alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            answ = alfWord;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length<30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
            DragLetterCreateLocation();
        }
        else if (SelectTheme.numTheme == 2)
        {
            rndNumQuest = Random.Range(10, 20);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question;
            alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length < 30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
        }
        else if (SelectTheme.numTheme == 3)
        {
            rndNumQuest = Random.Range(20, 30);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question;
            alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length < 30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
        }
        else if (SelectTheme.numTheme == 4)
        {
            rndNumQuest = Random.Range(30, 40);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question;
            alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length < 30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
        }
        else if (SelectTheme.numTheme == 5)
        {
            rndNumQuest = Random.Range(40, 50);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question;
            alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length < 30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
        }
        else if (SelectTheme.numTheme == 6)
        {
            rndNumQuest = Random.Range(50, 60);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question;
            alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length < 30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
        }
        else if (SelectTheme.numTheme == 7)
        {
            rndNumQuest = Random.Range(60, 70);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question; alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length < 30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
        }
        else if (SelectTheme.numTheme == 8)
        {
            rndNumQuest = Random.Range(0, 70);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Question);
            Debug.Log(FillQuiz.listQestions[rndNumQuest].Answer);
            text.text = FillQuiz.listQestions[rndNumQuest].Question;
            alfWord = FillQuiz.listQestions[rndNumQuest].Answer;
            alfWord = alfWord.ToUpper();
            check_ans = alfWord.Length;
            string alf = "�������������������������������ި";
            for (int i = 0; alfWord.Length < 30; i++)
            {
                int rndChar = Random.Range(0, 33);
                int sum = 0;
                for (int j = 0; j < alfWord.Length; j++)
                {
                    if (alfWord[j] == alf[rndChar]) sum++;
                }
                if (sum == 0) alfWord += alf[rndChar];
            }
            Debug.Log(alfWord);
            char[] newAlf = alfWord.ToCharArray();
            for (int i = 0; i < newAlf.Length; i++)
            {
                int rndChar = Random.Range(0, 30);
                char buf = newAlf[i];
                newAlf[i] = newAlf[rndChar];
                newAlf[rndChar] = buf;
            }
            alfWord = "";
            for (int i = 0; i < newAlf.Length; i++)
            {
                alfWord += newAlf[i];
            }
            Debug.Log(alfWord);
        }
    }

    public void Remove()
    {

        remove = true;
        string newAlfword = "";
        foreach (char letter in alfWord)
        {
            if (answ.Contains(letter.ToString()))
            {
                newAlfword += letter;

            }
            else
            {
                Destroy(GameObject.Find(letter.ToString()));
            }
        }
        alfWord = newAlfword;
        remove = false;
    }
    public void RNDLetter()
    {
     
    }
    // Update is called once per frame
    void Update()
    {

    }

    void DragLetterCreateLocation() // ��������� ���� �� �����
    {
        float x = -9 * 70 / 2;
        float y = -450;
        float count = 0;
        for (int i = 0; i < 30; i++)
        {
            if (count < 10)
            {
            dragLocation = Instantiate(dragLetter, new Vector3(x,y,0), Quaternion.identity);
            dragLocation.transform.SetParent(canvas.transform, false);
            dragLocation.GetComponentInChildren<Text>().text = alfWord[i].ToString();
            dragLocation.name = alfWord[i].ToString();
            x += 99;
            count++;
            }
            else
            {
                count = 0;
                x = -9 * 70 / 2;
                y -= -70;
                i--;
            }
        }
        x = -120f * (FillQuiz.listQestions[rndNumQuest].Answer.Length-1) / 2;
        y = -200;
        for (int i = 0; i < FillQuiz.listQestions[rndNumQuest].Answer.Length; i++) 
        {
            emptyLetter = Instantiate(emptyLetter, new Vector3(x, y, 0), Quaternion.identity);
            emptyLetter.transform.SetParent(canvas.transform, false);
            emptyLetter.name = i.ToString();
            // dragLocation.GetComponentInChildren<Text>().text = alfWord[i].ToString();
            x += 110;
        }
    }
}