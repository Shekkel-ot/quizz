using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ButtonHint : MonoBehaviour
{
    public Text text;
    public Text timer;
    bool btn_free_word;
    bool btn_skip_word;
    
    
  
    void Start()
    {
        btn_skip_word = false;
        btn_free_word = false;
    }
    public void Btn_click_free()
    {
        if (! btn_free_word) 
        {
            btn_free_word = true;
            text.text = "����� �� ������ ������ ���: " + CreateGameLocation.answ;
            btn_free_word = false;
        }
    }
    public void Btn_skip_word()
    {
        if (! btn_skip_word)
        {
            btn_skip_word = true;
            SceneManager.LoadScene("Game");
            btn_skip_word = false;
            CoinsScript.CoinRemove(100);


        }
    }

    

    void Update()
    {
        

    }
}
