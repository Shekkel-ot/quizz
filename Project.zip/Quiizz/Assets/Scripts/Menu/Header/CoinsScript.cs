using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CoinsScript : MonoBehaviour
{
    public Text coins;
    public static int coin;
    bool btn_50;
    bool btn_100;
    bool btn_300;
    bool btn_1000;
    // Start is called before the first frame update
    void Start()
    {
        bool btn_50 = false;
    }
    public void Buy_coins_50()
    {
        if (!btn_50)
        {
            btn_50 = true;
            coin += 50;
            coins.text = Convert.ToString(coin);
            btn_50 = false;
        }
    }
    public void Buy_coins_100()
    {
        if (!btn_100)
        {
            btn_100 = true;
            coin += 100;
            coins.text = Convert.ToString(coin);
            btn_100 = false;
        }
    }
    public void Buy_coins_300()
    {
        if (!btn_300)
        {
            btn_300 = true;
            coin += 300;
            coins.text = Convert.ToString(coin);
            btn_300 = false;
        }
    }
    public void Buy_coins_1000()
    {
        if (!btn_1000)
        {
            btn_1000 = true;
            coin += 1000;
            coins.text = Convert.ToString(coin);
            btn_1000 = false;
        }
    }

    public static void CoinRemove(int ammount)
    {
        coin -= ammount;

    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
