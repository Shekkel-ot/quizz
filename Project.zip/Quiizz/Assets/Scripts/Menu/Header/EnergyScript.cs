using System;
using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.UI;
using static UnityEngine.EventSystems.EventTrigger;

public class EnergyScript : MonoBehaviour
{
    public Text energy_text, time_energy_text;
    public static float second;
    public static int energy;
    TimeSpan timer = new TimeSpan();
    bool buy_1_energy;
    bool buy_5_energy;
    bool buy_30_energy;
    bool buy_100_energy;
    // Start is called before the first frame update
    void Start()
    {
        if (PlayerPrefs.HasKey("second"))
            second = PlayerPrefs.GetFloat("second");
        else
        {
            second = 10f;
            PlayerPrefs.SetFloat("second", second);
        }
        if (PlayerPrefs.HasKey("energy"))
            energy = PlayerPrefs.GetInt("energy");
        else
        {
            energy = 10;
            PlayerPrefs.SetInt("energy", energy);
        }
        energy_text.text = energy.ToString() + "/300";
        // energy = 0;
        
    }
    private void OnApplicationQuit()
    {
        PlayerPrefs.SetFloat("second", second);
        PlayerPrefs.Save();
        PlayerPrefs.SetInt("energy", energy);
        PlayerPrefs.Save();
        PlayerPrefs.SetInt("money", CoinsScript.coin);
        PlayerPrefs.Save();
    }
    // Update is called once per frame
    void Update()
    {
       if (second > 0)
        {
            second -= Time.deltaTime;
            timer = new TimeSpan(0,0, Convert.ToInt32(second));
            time_energy_text.text = timer.ToString("mm':'ss");
        }
       if (second <= 0)
        {
            energy++;
            energy_text.text = energy.ToString() + "/300";
            second = 1f;
        }
       if (energy >= 300)
        {
            energy = 300;
            time_energy_text.text = "��������";
        }
        if (energy >= 300)
        {
            second = 10f;
        }
    }
    public void Buy_1_energy()
    {
        if (!buy_1_energy)
        {
            buy_1_energy = true;
            energy += 1;
            energy_text.text = Convert.ToString(energy) + "/300";
            buy_1_energy = false;
        }
    }
    public void Buy_5_energy()
    {
        if (!buy_5_energy)
        {
            buy_5_energy = true;
            energy += 5;
            energy_text.text = Convert.ToString(energy) + "/300";
            buy_5_energy = false;
        }
    }
    public void Buy_30_energy()
    {
        if (!buy_30_energy)
        {
            buy_30_energy = true;
            energy += 30;
            energy_text.text = Convert.ToString(energy) + "/300";
            buy_30_energy = false;
        }
    }
    public void Buy_100_energy()
    {
        if (!buy_100_energy)
        {
            buy_100_energy = true;
            energy += 100;
            energy_text.text = Convert.ToString(energy) + "/300";
            buy_100_energy = false;
        }
    }
}
