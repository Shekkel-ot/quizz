using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SettingScript : MonoBehaviour
{
    public GameObject panel_setting;
    public GameObject close_snd;
    public GameObject close_muz;
    bool btn;
    bool btn_vol;
    bool btn_mus;
    // Start is called before the first frame update
    void Start()
    {
        panel_setting.SetActive(false);
        close_snd.SetActive(false);
        close_muz.SetActive(false);
        btn = false;
        btn_vol = false;
        btn_mus = false;
    }

    // Update is called once per frame
    public void Btn_set_click()
    {
        if (!btn)
        {
            panel_setting.SetActive(true);
            btn = true;
        }
        else
        {
            panel_setting.SetActive(false);
            btn = false;
        }
    }
    public void Btn_click_off()
    {
        if (!btn_vol)
        {
            close_snd.SetActive(true);
            btn_vol = true;
        }
        else
        {
            close_snd.SetActive(false);
            btn_vol = false;
        }
    }
    public void Btn_click_off_mus()
    {
        if (!btn_mus)
        {
            close_muz.SetActive(true);
            btn_mus = true;
        }
        else
        {
            close_muz.SetActive(false);
            btn_mus = false;
        }
    }
}
