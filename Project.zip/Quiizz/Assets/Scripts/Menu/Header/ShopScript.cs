using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ShopScript : MonoBehaviour
{
    public GameObject shop;
    public GameObject black_screen;
    bool buy_btn;
    bool close_menu;
    void Start()
    {
        shop.SetActive(false);
        black_screen.SetActive(false);
        buy_btn = false;
        close_menu = false;
    }
    public void Btn_on()
    {
        if (!buy_btn)
        {
            black_screen.SetActive(true);
            shop.SetActive(true);
            buy_btn = true;
        }
        else
        {
            black_screen.SetActive(false);
            shop.SetActive(false);
            buy_btn = false;
        }
    }
    public void Shop_close()
    {
        if (!close_menu)
        {
            black_screen.SetActive(false);
            shop.SetActive(false);
            buy_btn = false;
            close_menu = false;
        }
    }
    void Update()
    {

    }
}
