using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ShopItemsScripts : MonoBehaviour
{
    public Button btn_sh1;
    public Button btn_sh2;
    public Button btn_sh3;
    public Button btn_sh4;
    public Text TxtM;

    private int balance = 0;

    void Start()
    {
        LoadBalance(); // Load the balance from PlayerPrefs
        UpdateBalanceText();

        btn_sh1.onClick.AddListener(BuyItem1);
        btn_sh2.onClick.AddListener(BuyItem2);
        btn_sh3.onClick.AddListener(BuyItem3);
        btn_sh4.onClick.AddListener(BuyItem4);
    }

    void BuyItem1()
    {
        AddToBalance(50);
    }

    void BuyItem2()
    {
        AddToBalance(100);
    }

    void BuyItem3()
    {
        AddToBalance(500);
    }

    void BuyItem4()
    {
        AddToBalance(1000);
    }

    void AddToBalance(int amount)
    {
        balance += amount;
        UpdateBalanceText();
        SaveBalance(); // Save the balance using PlayerPrefs
    }

    void UpdateBalanceText()
    {
        TxtM.text = balance.ToString();
    }

    void SaveBalance()
    {
        PlayerPrefs.SetInt("balance", balance);
        PlayerPrefs.Save();
    }

    void LoadBalance()
    {
        if (PlayerPrefs.HasKey("balance"))
        {
            balance = PlayerPrefs.GetInt("balance");
        }
        else
        {
            balance = 0;
        }
    }
}
