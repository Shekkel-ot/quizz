using JetBrains.Annotations;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class EnargyScript : MonoBehaviour
{
    public Text energy_text_text, energy_time_text;
    float second;
    int energy;
    TimeSpan timer = new TimeSpan();
    bool buy_1_energy;
    bool buy_5_energy;
    bool buy_30_energy;
    bool buy_100_energy;
    // Start is called before the first frame update
    void Start()
    {
        if (PlayerPrefs.HasKey("second"))
            second = PlayerPrefs.GetFloat("second");
        else
        {
            second = 10f;
            PlayerPrefs.SetFloat("second", second);
            PlayerPrefs.Save();
        }
        energy = 0;
        {
            if (PlayerPrefs.HasKey("energy"))
                energy = PlayerPrefs.GetInt("energy");
            else
            {
                energy = 50;
                PlayerPrefs.SetInt("energy", energy);
                PlayerPrefs.Save();
            }
            energy_text_text.text = energy.ToString() + "/300";
        }
        //energy = 0;
    }
    private void OnApplicationQuit()
    {
        PlayerPrefs.SetFloat("second", second);
        PlayerPrefs.Save();
        PlayerPrefs.SetInt("energy", energy);
        PlayerPrefs.Save();
    }
    // Update is called once per frame
    void Update()
    {
        if (second > 0)
        {
            second -= Time.deltaTime;
            timer = new TimeSpan(0, 0, Convert.ToInt32(second));
            energy_time_text.text = timer.ToString("mm':'ss");
        }
        if (second <= 0)
        {
            energy++;
            energy_text_text.text = energy.ToString() + "/300";
            second = 10f;
        }
        if (energy >= 300)
        {
            second = 10f;
        }
    }
    public void Buy_1_energy()
    {
        if (!buy_1_energy)
        {
            buy_1_energy = true;
            energy += 50;
            energy_text_text.text = Convert.ToString(energy) + "/300";
            buy_1_energy = false;
        }
    }
    public void Buy_5_energy()
    {
        if (!buy_5_energy)
        {
            buy_5_energy = true;
            energy += 15;
            energy_text_text.text = Convert.ToString(energy) + "/300";
            buy_5_energy = false;
        }
    }
    public void Buy_30_energy()
    {
        if (!buy_30_energy)
        {
            buy_30_energy = true;
            energy += 30;
            energy_text_text.text = Convert.ToString(energy) + "/300";
            buy_30_energy = false;
        }
    }
    public void Buy_100_energy()
    {
        if (!buy_100_energy)
        {
            buy_100_energy = true;
            energy += 100;
            energy_text_text.text = Convert.ToString(energy) + "/300";
            buy_100_energy = false;
        }
    }

}
